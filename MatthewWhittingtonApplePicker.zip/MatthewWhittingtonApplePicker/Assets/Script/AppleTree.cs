using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class AppleTree : MonoBehaviour
{
    //prefab for instantiating apples
    public GameObject applePrefab;
    //Speed at which the AppleTree moves
    //public float speed = 1f;
    //Distance where AppleTree turns around
    public float leftAndRightEdge = 10f;
    //chance that the AppleTree will change directions
    //public float chanceToChangeDirections = .1f;
    //Rate at which Apples will be instantiated
    //public float secondsBetweenAppleDrops = 1f;

    float[] speed = { 20f, 25f, 30f };
    float[] chanceToChangeDirections = { .02f, .02f, .05f };
    float[] secondsBetweenAppleDrops = { 1f, .5f, .35f };
    int index = 0;
    bool level1=false;
    public Text levelScore;
    public Text scoreCounter;
    int score;

    // Start is called before the first frame update
    void Start()
    {
        GameObject scoreText = GameObject.Find("Level");
        levelScore = scoreText.GetComponent<Text>();
        levelScore.text = "Level 1";

        Invoke("DropApple", 2f);
    }

    void DropApple()
    {
        GameObject apple = Instantiate<GameObject>(applePrefab);
        apple.transform.position = transform.position;
        Invoke("DropApple", secondsBetweenAppleDrops[index]);
    }

    // Update is called once per frame
    void Update()
    {
        //Basic Movement
        Vector3 pos = transform.position;
        pos.x += speed[index] * Time.deltaTime;
        transform.position = pos;

        //Changing Direction
        float temp = speed[index];
        if (pos.x < -leftAndRightEdge)
        {
            speed[index] = Mathf.Abs(speed[index]);
        }else if (pos.x > leftAndRightEdge)
        {
            speed[index] = -Mathf.Abs(speed[index]);
        }

        GameObject ScoreCT = GameObject.Find("ScoreCounter");
        scoreCounter = ScoreCT.GetComponent<Text>();
        score = int.Parse(scoreCounter.text);

        Debug.Log("This is the High Score " + HighScore.score);
        if (score == 2000 && level1==false)
        {
            level1 = true;
            index = 1;
            score = 0;
            scoreCounter.text = "0";
            levelScore.text = "level 2";
        }
        if(score==3000 && level1 == true)
        {
            index = 2;
            score = 0;
            scoreCounter.text = "0";
            levelScore.text = "level 3";
        }
    }
    private void FixedUpdate()
    {
        if (Random.value < chanceToChangeDirections[index])
        {
            speed[index] *= -1;
        }
    }
}
