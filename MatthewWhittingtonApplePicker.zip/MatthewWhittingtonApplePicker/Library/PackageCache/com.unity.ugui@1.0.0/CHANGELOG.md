# Changelog

## [1.0.0] - 2019-01-08
This is the first release of Unity UI as a built in package.
